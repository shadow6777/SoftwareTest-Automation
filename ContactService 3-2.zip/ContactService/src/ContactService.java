import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ContactService {
	static List<Contact> contactList = new ArrayList<>();
	
	{
		UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	public static void newContact() {
		Contact contact = new Contact(newUniqueId());
		contactList.add(contact);
	}
	public void newContact(String firstname) {
		Contact contact = new Contact(newUniqueId(), firstname);
		contactList.add(contact);
	}
	public void newContact(String firstname, String lastname) {
		Contact contact = new Contact(newUniqueId(),firstname, lastname);
		contactList.add(contact);
	}
	public void newContact(String firstname, String lastname, String phonenumber) {
		Contact contact = new Contact(newUniqueId(), firstname, lastname, phonenumber);
		contactList.add(contact);
	}
	public static void newContact(String firstname, String lastname, String phonenumber, String address) {
		Contact contact = new Contact(newUniqueId(), firstname, lastname, phonenumber, address);
		contactList.add(contact);
	}
	public static void updateFirstName(String id, String firstName) throws Exception {
		searchForContact(id).updateFirstName(firstName);
	}
	public static void updateLastName(String id, String lastName) throws Exception {
		searchForContact(id).updateLastName(lastName);
	}
	public static void updatePhoneNumber(String id, String phoneNumber) throws Exception {
		searchForContact(id).updatePhoneNumber(phoneNumber);
	}
	public static void updateAddress(String id, String address) throws Exception {
		searchForContact(id).updateAddress(address);
	}
	
	protected List<Contact> getContactList() {
		return contactList; 
		}
	private static String newUniqueId() {
		return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
		}
	private static Contact searchForContact(String id) throws Exception {
		int index = 0;
		while (index < contactList.size()) {
			if (id.equals(contactList.get(index).getContactId())) {
				return contactList.get(index);
			}
			index++;
		}
		throw new Exception("Incorrect input.");
	}
	public static int findIndex(String string) {
		// TODO Auto-generated method stub
		return 0;
	}
	public static void deleteContact(String string) {
		// TODO Auto-generated method stub
		
	}
	public static int searchContact(String string) {
		// TODO Auto-generated method stub
		return 0;
	}
}
