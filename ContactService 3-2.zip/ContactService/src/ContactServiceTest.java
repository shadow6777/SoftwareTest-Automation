import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

	//create a contact and test values
	// this creates contacts with a unique ID using the ContactService addContact method
	@Test
	void testContactServiceClass() {
		ContactService.newContact("John", "Doe", "6788675309", "368 Clement St. Atlanta, Ga 30303");
		//System.out.println(ContactService.contactList.get(0).getId());	will be used for debugging
		assertTrue(ContactService.contactList.get(0).getContactId().equals("0123456789"));
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("John"));
		assertTrue(ContactService.contactList.get(0).getLastName().equals("Doe"));
		assertTrue(ContactService.contactList.get(0).getPhoneNumber().equals("6788675309"));
		assertTrue(ContactService.contactList.get(0).getAddress().equals("368 Clement St. Atlanta, Ga 30303"));
	}
	// confirm deletion of a contact
	@Test
	void testContactServiceDelete() {
		ContactService.newContact("John", "Doe", "6788675309", 
				"368 Clement St. Atlanta, Ga 30303");
		int size = ContactService.contactList.size();
		//System.out.println(ContactService.contactList.get(size - 1).getId());
		ContactService.deleteContact("1234567890");
		//ContactService.searchContact("1234567890");
		//System.out.println(ContactService.contactList.get(1).getId());
		assertTrue(ContactService.searchContact("1234567890") == 2);
	}
	// update first name test
	@Test
	void testContactServiceUpdateFirstName() throws Exception {
		ContactService.newContact("John", "Jaeger", "6788883091", "Random Ave.");
		int size = ContactService.contactList.size();
		System.out.println(ContactService.contactList.get(size - 1).getContactId());
		System.out.println(ContactService.contactList.get(size - 1).getFirstName());
		ContactService.updateFirstName("1234567890", "Steve");
		System.out.println(ContactService.contactList.get(size - 1).getFirstName());
		assertTrue(ContactService.contactList.get(size - 1).getFirstName().equals("Steve"));
	}
	@Test
	void testContactServiceUpdateLastName() throws Exception {
		int size = ContactService.contactList.size();
		ContactService.updateLastName("1234567890", "Harris");
		assertTrue(ContactService.contactList.get(size - 1).getLastName().equals("Harris"));
	}
	// test confirming update to phone number
	@Test
	void testContactServiceUpdatePhone() throws Exception {
		int target = 0;
		target = ContactService.findIndex("1234567890");
		ContactService.updatePhoneNumber("1234567890", "8003685152");
		assertTrue(ContactService.contactList.get(target).getPhoneNumber().equals("8003685152"));
	}
	// test confirming update to address
	@Test
	void testContactServiceUpdateAddress() throws Exception {
		int target = 0;
		target = ContactService.findIndex("1234567890");
		ContactService.updateAddress("1234567890", "561 Fake St. Macon, Ga 31709");
		assertTrue(ContactService.contactList.get(target).getAddress().equals("561 Fake St. Macon, Ga 31709"));
	}
	
	// test to confirm unique ID
	@Test
	void testContactServiceUniqueId() {
		Contact newContact = new Contact("36594", "Rich", "Gallo", "4702017664", "Original Contact Address");
		ContactService.newContact();
		Contact duplicateId = new Contact("36594", "Rich", "Gallo", "4702017664", "Duplicate Contact Address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			ContactService.newContact();
		});
	}

}

