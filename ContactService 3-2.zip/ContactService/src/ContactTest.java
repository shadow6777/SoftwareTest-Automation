import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactTest {
	
	// test for working contact creation
	@Test
	void testContactClass() {
		Contact newContact = new Contact("12345", "John", "Doe", "6788675309", 
				"368 Clement St. Atlanta, Ga 30303");
		assertTrue(newContact.getFirstName().equals("John"));
		assertTrue(newContact.getLastName().equals("Doe"));
		assertTrue(newContact.getContactId().equals("12345"));
		assertTrue(newContact.getPhoneNumber().equals("6788675309"));
		assertTrue(newContact.getAddress().equals("368 Clement St. Atlanta, Ga 30303"));
	}
	private void assertTrue(boolean equals) {
		// TODO Auto-generated method stub
		
	}
	// test for too long ID
	@Test
	void testContactClassIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "John", "Doe", "6788675309", 
				"368 Clement St. Atlanta, Ga 30303");
		});
	}
	// test for null ID
	@Test
	void testContactClassIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "John", "Doe", "6788675309", 
					"368 Clement St. Atlanta, Ga 30303");
		});
	}
	// test for too long first name
	@Test
	void testContactClassFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John1234567", "Doe", "6788675309", 
					"368 Clement St. Atlanta, Ga 30303");
		});
	}
	// test for null first name
	@Test
	void testContactClassFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", null, "Doe", "6788675309",
					"368 Clement St. Atlanta, Ga 30303");
		});
	}
	// test for too long last name
	@Test
	void testContactClassLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doe12345678", "6788675309", 
					"368 Clement St. Atlanta, Ga 30303");
		});
	}
	// test for null last name
	@Test
	void testContactClassLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", null, "6788675309", 
					"368 Clement St. Atlanta, Ga 30303");
		});
	}
	// test for not exactly 10 characters
	@Test
	void testContactClassPhoneNot10() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doe", "678867530", 
					"368 Clement St. Atlanta, Ga 30303");
		});
	}
	// test for null phone
	@Test
	void testContactCalssPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doe", null, 
					"368 Clement St. Atlanta, Ga 30303");
		});
	}
	// test for too long address
	@Test
	void testContactClassAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doe", "6788675309", 
					"368 Clement St. Atlanta, Ga 30303 1234567");
		});
	}
	// test for null address
	@Test
	void testContactClassAddressnull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doe", "6788675309", 
					null);
		});
	}
	// test fName setter method
	@Test
	void testContactClassSetFirstName() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		newContact.updateFirstName("John");
		assertTrue(newContact.getFirstName().equals("John"));
	}
	@Test
	void testContactClassSetFirstNameTooLong() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.updateFirstName("JohnIsTooLong");
		});
	}
	@Test
	void testContactClassSetFirstNameNull() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.updateFirstName(null);
		});
	}
	// test lName setter method
	@Test
	void testContactClassSetLastName() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		newContact.updateLastName("Jones");
		assertTrue(newContact.getLastName().equals("Jones"));
	}
	@Test
	void testContactClassSetLastNameTooLong() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.updateLastName("JonesIsTooLong");
		});
	}
	@Test
	void testContactClassSetLastNameNull() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.updateLastName(null);
		});
	}
	// test phone setter method
	@Test
	void testContactClassSetPhone() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		newContact.updatePhoneNumber("6788675309");
		assertTrue(newContact.getPhoneNumber().equals("6788675309"));
	}
	@Test
	void testContactClassSetPhoneTooLong() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.updatePhoneNumber("67886753099999999");
		});
	}
	@Test
	void testContactClassSetPhoneNull() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.updatePhoneNumber(null);
		});
	}
	@Test
	void testContactClassSetPhoneTooShort() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.updatePhoneNumber("123456");
		});
	}
	// test address setter method
	@Test
	void testContactClassSetAddress() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		newContact.updateAddress("new address 2");
		assertTrue(newContact.getAddress().equals("new address 2"));
	}
	@Test
	void testContactClassSetAddressTooLong() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.updateAddress("new address is too long 1324566874685");
		});
	}
	@Test
	void testContactClassSetAddressNull() {
		Contact newContact = new Contact("345", "John", "Jones", "6788675309", "new address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.updateAddress(null);
		});
	}
	

}

